# -*- coding: utf-8 -*-
# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.cloud.dialogflow_v3alpha1.types import data_store_connection
from google.cloud.dialogflow_v3alpha1.types import inline
from google.protobuf import field_mask_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v3alpha1',
    manifest={
        'CreateToolRequest',
        'ListToolsRequest',
        'ListToolsResponse',
        'GetToolRequest',
        'ExportToolsRequest',
        'ExportToolsResponse',
        'UpdateToolRequest',
        'DeleteToolRequest',
        'Tool',
        'ExportToolsMetadata',
    },
)


class CreateToolRequest(proto.Message):
    r"""The request message for
    [Tools.CreateTool][google.cloud.dialogflow.v3alpha1.Tools.CreateTool].

    Attributes:
        parent (str):
            Required. The agent to create a Tool for. Format:
            ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>``.
        tool (google.cloud.dialogflow_v3alpha1.types.Tool):
            Required. The Tool to be created.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    tool: 'Tool' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='Tool',
    )


class ListToolsRequest(proto.Message):
    r"""The request message for
    [Tools.ListTools][google.cloud.dialogflow.v3alpha1.Tools.ListTools].

    Attributes:
        parent (str):
            Required. The agent to list the Tools from. Format:
            ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>``.
        page_size (int):
            The maximum number of items to return in a
            single page. By default 100 and at most 1000.
        page_token (str):
            The next_page_token value returned from a previous list
            request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListToolsResponse(proto.Message):
    r"""The response message for
    [Tools.ListTools][google.cloud.dialogflow.v3alpha1.Tools.ListTools].

    Attributes:
        tools (MutableSequence[google.cloud.dialogflow_v3alpha1.types.Tool]):
            The list of Tools. There will be a maximum number of items
            returned based on the page_size field in the request.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    tools: MutableSequence['Tool'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='Tool',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class GetToolRequest(proto.Message):
    r"""The request message for
    [Tools.GetTool][google.cloud.dialogflow.v3alpha1.Tools.GetTool].

    Attributes:
        name (str):
            Required. The name of the Tool. Format:
            ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>/tools/<Tool ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ExportToolsRequest(proto.Message):
    r"""The request message for
    [Tools.ExportTools][google.cloud.dialogflow.v3alpha1.Tools.ExportTools].

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        parent (str):
            Required. The agent to export tools from. Format:
            ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>``.
        tools (MutableSequence[str]):
            Required. The name of the tools to export. Format:
            ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>/tools/<Tool ID>``.
        tools_uri (str):
            Optional. The `Google Cloud
            Storage <https://cloud.google.com/storage/docs/>`__ URI to
            export the tools to. The format of this URI must be
            ``gs://<bucket-name>/<object-name>``.

            Dialogflow performs a write operation for the Cloud Storage
            object on the caller's behalf, so your request
            authentication must have write permissions for the object.
            For more information, see `Dialogflow access
            control <https://cloud.google.com/dialogflow/cx/docs/concept/access-control#storage>`__.

            This field is a member of `oneof`_ ``destination``.
        tools_content_inline (bool):
            Optional. The option to return the serialized
            tools inline.

            This field is a member of `oneof`_ ``destination``.
        data_format (google.cloud.dialogflow_v3alpha1.types.ExportToolsRequest.DataFormat):
            Optional. The data format of the exported tools. If not
            specified, ``BLOB`` is assumed.
    """
    class DataFormat(proto.Enum):
        r"""Data format of the exported tools.

        Values:
            DATA_FORMAT_UNSPECIFIED (0):
                Unspecified format. Treated as ``BLOB``.
            BLOB (1):
                Tools will be exported as raw bytes.
            JSON (2):
                Tools will be exported in JSON format.
        """
        DATA_FORMAT_UNSPECIFIED = 0
        BLOB = 1
        JSON = 2

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    tools: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=2,
    )
    tools_uri: str = proto.Field(
        proto.STRING,
        number=3,
        oneof='destination',
    )
    tools_content_inline: bool = proto.Field(
        proto.BOOL,
        number=4,
        oneof='destination',
    )
    data_format: DataFormat = proto.Field(
        proto.ENUM,
        number=5,
        enum=DataFormat,
    )


class ExportToolsResponse(proto.Message):
    r"""The response message for
    [Tools.ExportTools][google.cloud.dialogflow.v3alpha1.Tools.ExportTools].

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        tools_uri (str):
            The URI to a file containing the exported tools. This field
            is populated only if ``tools_uri`` is specified in
            [ExportToolsRequest][google.cloud.dialogflow.v3alpha1.ExportToolsRequest].

            This field is a member of `oneof`_ ``tools``.
        tools_content (google.cloud.dialogflow_v3alpha1.types.InlineDestination):
            Uncompressed byte content for tools. This field is populated
            only if ``tools_content_inline`` is set to true in
            [ExportToolsRequest][google.cloud.dialogflow.v3alpha1.ExportToolsRequest].

            This field is a member of `oneof`_ ``tools``.
    """

    tools_uri: str = proto.Field(
        proto.STRING,
        number=1,
        oneof='tools',
    )
    tools_content: inline.InlineDestination = proto.Field(
        proto.MESSAGE,
        number=2,
        oneof='tools',
        message=inline.InlineDestination,
    )


class UpdateToolRequest(proto.Message):
    r"""The request message for
    [Tools.UpdateTool][google.cloud.dialogflow.v3alpha1.Tools.UpdateTool].

    Attributes:
        tool (google.cloud.dialogflow_v3alpha1.types.Tool):
            Required. The Tool to be updated.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            The mask to control which fields get updated.
            If the mask is not present, all fields will be
            updated.
    """

    tool: 'Tool' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='Tool',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class DeleteToolRequest(proto.Message):
    r"""The request message for
    [Tools.DeleteTool][google.cloud.dialogflow.v3alpha1.Tools.DeleteTool].

    Attributes:
        name (str):
            Required. The name of the Tool to be deleted. Format:
            ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>/tools/<Tool ID>``.
        force (bool):
            This field has no effect for Tools not being used. For Tools
            that are used:

            -  If ``force`` is set to false, an error will be returned
               with message indicating the referenced resources.
            -  If ``force`` is set to true, Dialogflow will remove the
               tool, as well as any references to the tool.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    force: bool = proto.Field(
        proto.BOOL,
        number=2,
    )


class Tool(proto.Message):
    r"""A tool provides a list of actions which are available to the
    [Playbook][google.cloud.dialogflow.v3alpha1.Playbook] to attain its
    goal. A Tool consists of a description of the tool's usage and a
    specification of the tool which contains the schema and
    authentication information.

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        name (str):
            The unique identifier of the Tool. Format:
            ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>/tools/<Tool ID>``.
        display_name (str):
            Required. The human-readable name of the
            Tool, unique within an agent.
        description (str):
            Required. High level description of the Tool
            and its usage.
        actions (MutableSequence[str]):
            The list of derived action names for the
            tool.
        schemas (MutableSequence[str]):
            The list of derived type schemas for the
            tool.
        open_api_spec (google.cloud.dialogflow_v3alpha1.types.Tool.OpenApiTool):
            OpenAPI specification of the Tool.

            This field is a member of `oneof`_ ``specification``.
        data_store_spec (google.cloud.dialogflow_v3alpha1.types.Tool.DataStoreTool):
            Data store search tool specification.

            This field is a member of `oneof`_ ``specification``.
        extension_spec (google.cloud.dialogflow_v3alpha1.types.Tool.ExtensionTool):
            Vertex extension tool specification.

            This field is a member of `oneof`_ ``specification``.
    """

    class OpenApiTool(proto.Message):
        r"""An OpenAPI tool is a way to provide the Tool specifications
        in the Open API schema format.


        .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

        Attributes:
            text_schema (str):
                Required. The OpenAPI schema specified as a
                text.

                This field is a member of `oneof`_ ``schema``.
        """

        text_schema: str = proto.Field(
            proto.STRING,
            number=1,
            oneof='schema',
        )

    class DataStoreTool(proto.Message):
        r"""A DataStoreTool is a way to provide specifications needed to
        search a list of data stores.

        Attributes:
            data_store_connections (MutableSequence[google.cloud.dialogflow_v3alpha1.types.DataStoreConnection]):
                Required. List of data stores to search.
        """

        data_store_connections: MutableSequence[data_store_connection.DataStoreConnection] = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message=data_store_connection.DataStoreConnection,
        )

    class ExtensionTool(proto.Message):
        r"""An ExtensionTool is a way to use Vertex Extensions as a tool.

        Attributes:
            name (str):
                Required. The full name of the referenced vertex extension.
                Formats:
                ``projects/{project}/locations/{location}/extensions/{extension}``
        """

        name: str = proto.Field(
            proto.STRING,
            number=1,
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=2,
    )
    description: str = proto.Field(
        proto.STRING,
        number=3,
    )
    actions: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=6,
    )
    schemas: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=7,
    )
    open_api_spec: OpenApiTool = proto.Field(
        proto.MESSAGE,
        number=4,
        oneof='specification',
        message=OpenApiTool,
    )
    data_store_spec: DataStoreTool = proto.Field(
        proto.MESSAGE,
        number=8,
        oneof='specification',
        message=DataStoreTool,
    )
    extension_spec: ExtensionTool = proto.Field(
        proto.MESSAGE,
        number=11,
        oneof='specification',
        message=ExtensionTool,
    )


class ExportToolsMetadata(proto.Message):
    r"""Metadata returned for the
    [Tools.ExportTools][google.cloud.dialogflow.v3alpha1.Tools.ExportTools]
    long running operation.

    """


__all__ = tuple(sorted(__protobuf__.manifest))
