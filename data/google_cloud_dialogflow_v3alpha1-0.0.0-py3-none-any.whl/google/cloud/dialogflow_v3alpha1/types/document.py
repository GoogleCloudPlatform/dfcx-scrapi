# -*- coding: utf-8 -*-
# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.rpc import status_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v3alpha1',
    manifest={
        'ImportDocumentsResponse',
        'GenericKnowledgeOperationMetadata',
        'CreateDocumentOperationMetadata',
        'UpdateDocumentOperationMetadata',
        'DeleteDocumentOperationMetadata',
        'ImportDocumentsOperationMetadata',
        'ReloadDocumentOperationMetadata',
    },
)


class ImportDocumentsResponse(proto.Message):
    r"""Response message for
    [Documents.ImportDocuments][google.cloud.dialogflow.v3alpha1.Documents.ImportDocuments].

    Attributes:
        warnings (MutableSequence[google.rpc.status_pb2.Status]):
            Includes details about skipped documents or
            any other warnings.
    """

    warnings: MutableSequence[status_pb2.Status] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=status_pb2.Status,
    )


class GenericKnowledgeOperationMetadata(proto.Message):
    r"""Metadata in google::longrunning::Operation for Knowledge
    operations.

    Attributes:
        state (google.cloud.dialogflow_v3alpha1.types.GenericKnowledgeOperationMetadata.State):
            Required. Output only. The current state of
            this operation.
    """
    class State(proto.Enum):
        r"""States of the operation.

        Values:
            STATE_UNSPECIFIED (0):
                State unspecified.
            PENDING (1):
                The operation has been created.
            RUNNING (2):
                The operation is currently running.
            DONE (3):
                The operation is done, either cancelled or
                completed.
        """
        STATE_UNSPECIFIED = 0
        PENDING = 1
        RUNNING = 2
        DONE = 3

    state: State = proto.Field(
        proto.ENUM,
        number=1,
        enum=State,
    )


class CreateDocumentOperationMetadata(proto.Message):
    r"""Metadata for CreateDocument operation.

    Attributes:
        generic_metadata (google.cloud.dialogflow_v3alpha1.types.GenericKnowledgeOperationMetadata):
            The generic information of the operation.
    """

    generic_metadata: 'GenericKnowledgeOperationMetadata' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='GenericKnowledgeOperationMetadata',
    )


class UpdateDocumentOperationMetadata(proto.Message):
    r"""Metadata for UpdateDocument operation.

    Attributes:
        generic_metadata (google.cloud.dialogflow_v3alpha1.types.GenericKnowledgeOperationMetadata):
            The generic information of the operation.
    """

    generic_metadata: 'GenericKnowledgeOperationMetadata' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='GenericKnowledgeOperationMetadata',
    )


class DeleteDocumentOperationMetadata(proto.Message):
    r"""Metadata for DeleteDocument operation.

    Attributes:
        generic_metadata (google.cloud.dialogflow_v3alpha1.types.GenericKnowledgeOperationMetadata):
            The generic information of the operation.
    """

    generic_metadata: 'GenericKnowledgeOperationMetadata' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='GenericKnowledgeOperationMetadata',
    )


class ImportDocumentsOperationMetadata(proto.Message):
    r"""Metadata for ImportDocuments operation.

    Attributes:
        generic_metadata (google.cloud.dialogflow_v3alpha1.types.GenericKnowledgeOperationMetadata):
            The generic information of the operation.
    """

    generic_metadata: 'GenericKnowledgeOperationMetadata' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='GenericKnowledgeOperationMetadata',
    )


class ReloadDocumentOperationMetadata(proto.Message):
    r"""Metadata for ReloadDocument operation.

    Attributes:
        generic_metadata (google.cloud.dialogflow_v3alpha1.types.GenericKnowledgeOperationMetadata):
            The generic information of the operation.
    """

    generic_metadata: 'GenericKnowledgeOperationMetadata' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='GenericKnowledgeOperationMetadata',
    )


__all__ = tuple(sorted(__protobuf__.manifest))
